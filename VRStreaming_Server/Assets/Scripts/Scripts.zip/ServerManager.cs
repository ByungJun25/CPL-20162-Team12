﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;

public class ServerManager : MonoBehaviour {

    bool[] isSeat = { true, true, true, true };
    private Vector3[] position = { new Vector3(-2.12f, 0.68f, 0f), new Vector3(-1.02f, 0.68f, 0f), new Vector3(-2.12f, -0.42f, 0f), new Vector3(-1.02f, -0.42f, 0f) };

    private string currentMessage = string.Empty;
    private Vector2 scrollPosition = Vector2.zero;
    public int MaximumLength = 100;

    /*
     * Public variable. 
     * IP: default value is 127.0.0.1
     * PORT: default value is 9090
     * clientPrefab: Prefab variable. You should assign client prefab here.
    */
    public string ipAddress = "127.0.0.1";
    public int portNumber = 9090;
    public GameObject clientPrefab;

    /*
     * SocketManager: This is Singleton Object. It manages the Socket List.
     * AccessController: This is class that control the connection of client. It works as thread. 
     * ClientManager: This is GameObject. When the client connect to server, it was made by server automatically. It get the packet from client and show the video.
    */
    private SocketManager socketManager;
    private AccessController accessController;
    private ClientManager clientManager;

    /*
     * This is Event for sending a message function.
     * All of client object register their method here.
     * When the event happen, all of the client object act their fucntion which send a message.
    */
    public static event Action<string> sendMessageEvent;

    /*
     * Those variables are for client object.
     * clientName: When the client connect to server, server assign the client name using count. e.g. client[1]
     * bufferSize: This is int value for buffer in ClientManager Object. Now, it is 1024.
     * count: This is client count. But when client disconnect, it doesn't decrease.
    */
    Socket clientSocket;
    string clientName = "";
    int clientNumber = 0;
    public int bufferSize = 1024;
    int count = 0;

    /*
     * When the server open, it make a SocketManager(singleton) and run the AccessController Class and CheckSocket method.
    */
    void Awake()
    {
        accessController = new AccessController(ipAddress, portNumber);
        socketManager = SocketManager.GetInstance;

        StartCoroutine(CheckSocket());
    }

    private void OnGUI()
    {
        //ClientListView();
        SendMessageToClient();
    }

    /*
     * This method check the client who already connect to server every second.
     * This methoud checkt the Queue in SocketManager every second.
     * If there is a socket in Queue, it make a client GameObject and initialize the client object. 
    */
    private IEnumerator CheckSocket()
    {
        Debug.Log("client Connection Check start");
        WaitForSeconds waitSec = new WaitForSeconds(1);

        while(true)
        {
            clientSocket = socketManager.GetSocket();

            if(clientSocket != null)
            {
                CreateScreen();
            }
            yield return waitSec;
        }
    }

    /*
     * This method for Event named sendMessageEvent.
     * When user who control the server input the some message on chat, this method send a message from server to client who was conneted.
     * But it didn't realize now, so if you want to use this, you should realize this method
    */
    void SendMessageToClient()
    {
        currentMessage = GUI.TextField(new Rect(Screen.width - 500, Screen.height - 50, 350, 30), currentMessage, MaximumLength);
        if (GUI.Button(new Rect(Screen.width - 145, Screen.height - 50, 50, 30), "Send"))
        {
            SendMessage();
        }
    }

    private void SendMessage()
    {
        if (!string.IsNullOrEmpty(currentMessage.Trim()))
        {
            if (sendMessageEvent != null)
            {
                sendMessageEvent(currentMessage);
            }
            currentMessage = string.Empty;
        }
    }

    private void ClientListView()
    {
        GUI.Box(new Rect(Screen.width - 600, Screen.height - 560, 150, 450), "Client List");
        scrollPosition = GUI.BeginScrollView(new Rect(Screen.width - 560, Screen.height - 540, 120, 400), scrollPosition, new Rect(0, 0, 100, 100), false, false);

        GUI.EndScrollView();

    }

    private void CreateScreen()
    {
        if(count > 4)
        {
            clientSocket.Close();
        }
        Debug.Log("Client Connect: " + clientSocket.RemoteEndPoint.ToString());
        GameObject client = (GameObject)Instantiate(clientPrefab);
        clientManager = client.GetComponent<ClientManager>();
        Vector3 pos = SeekSeat();
        clientName = "Client[" + clientNumber + "]";
        client.transform.name = clientName;
        clientManager.init(clientSocket, clientName, bufferSize, pos);
    }

    private Vector3 SeekSeat()
    {
        Vector3 seatPos = Vector3.zero;

        for (int i =0; i<isSeat.Length; i++)
        {
            if(isSeat[i])
            {
                seatPos = position[i];
                clientNumber = i+1;
                break;
            }
        }
        return seatPos;
    }
}
