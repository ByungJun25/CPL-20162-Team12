﻿using UnityEngine;
using System;
using System.Collections;
using System.Net.Sockets;
using System.Collections.Generic;
using System.Text;

public class ClientManager : MonoBehaviour
{
    /*
     * This is init Variable.
     * clientSocket: Socket for client.
     * buffer: buffer for packet.
     * clientName: Client Name that received from server.
    */
    private Socket clientSocket;
    private byte[] buffer = null;
    private string clientName;
    private int bytesRec = 0;

    private LinkedList<byte[]> receivedBox;
    private Queue<byte[]> arrangedBox;
    private Queue<byte[]> videoBox;

    /*
     * This method initialize all of variable in class.
     * It not only initialize but also add function which send message to client to SendMessageEvent event in ServerManager Script. 
     * Run the coroutine method after initialize.
     * coroutine method name is ReceiveVideo.
    */
    public void init(Socket clientSocket, string clientName, int bufferSize)
    {
        Debug.Log("Client prefab initialize");
        OnEnableSendMessage();
        this.clientSocket = clientSocket;
        this.clientName = clientName;
        buffer = new byte[bufferSize];

        receivedBox = new LinkedList<byte[]>();
        arrangedBox = new Queue<byte[]>();
        videoBox = new Queue<byte[]>();

        StartCoroutine(ReceiveVideo2());
    }

    /*
     * This is corountine method. It receives the packet from client who connect to server.
     * It not only get the packet but also show the video on Texture.
     * This method run every frame. 
     * If client disconnect to server, It will close the socket and delete itself(client game object) by itself.
    */
    IEnumerator ReceiveVideo()
    {
        while (true)
        {
            bytesRec = clientSocket.Receive(buffer);
            if (bytesRec <= 0)
            {
                Debug.Log("Client disconnect: " + clientName);
                clientSocket.Close();
                clientSocket = null;
                OnDisableSendMessage();
                Destroy(this.gameObject);
            }
            else
            {
                Texture2D tex = new Texture2D(640, 360);
                tex.LoadImage(buffer);
                GetComponent<Renderer>().material.mainTexture = tex;
                tex.Apply();
            }
            System.Array.Clear(buffer, 0, buffer.Length);
            yield return null;
        }
    }

    IEnumerator ReceiveVideo2()
    {
        bool isHeaderExtract = false; 

        int data_len = 0;
        int offset = 0;

        byte[] frame = {0};
        byte[] header = { 0, 0, 0, 0 };

        while (true)
        {
            bytesRec = 0;
            bytesRec = clientSocket.Receive(buffer, offset, (buffer.Length-offset), 0);
            offset += bytesRec;
            if (bytesRec <= 0)
            {
                Debug.Log("Client disconnect: " + clientName);
                clientSocket.Close();
                clientSocket = null;
                OnDisableSendMessage();
                Destroy(this.gameObject);
            }
            else
            {
                if(!isHeaderExtract)
                {
                    if(offset < 4)
                    {
                        continue;
                    }
                    Buffer.BlockCopy(buffer, 0, header, 0, header.Length);
                    data_len = BitConverter.ToInt32(header, 0);
                    if(buffer.Length < data_len)
                    {
                        Array.Resize<byte>(ref buffer, data_len);
                    }
                    Buffer.BlockCopy(buffer, header.Length, buffer, 0, offset - header.Length);
                    offset -= header.Length;
                    Array.Clear(header, 0, header.Length);
                    isHeaderExtract = true;
                }
                else
                {
                    if(offset >= data_len)
                    {
                        Array.Resize<byte>(ref frame, data_len);
                        Buffer.BlockCopy(buffer, 0, frame, 0, data_len);
                        ShowVideo(frame);
                        Array.Clear(frame, 0, frame.Length);
                        offset -= data_len;
                        Buffer.BlockCopy(buffer, data_len, buffer, 0, offset);
                        isHeaderExtract = false;
                    }
                }
            }
            yield return null;
        }
    }

    private void ShowVideo(byte[] frame)
    {
        Texture2D tex = new Texture2D(640, 360);
        tex.LoadImage(frame);
        GetComponent<Renderer>().material.mainTexture = tex;
        tex.Apply();
    }

    IEnumerator Receiver()
    {
        byte[] temp = {0};
        while(true)
        {
            bytesRec = clientSocket.Receive(buffer);
            if (bytesRec <= 0)
            {
                Debug.Log("Client disconnect: " + clientName);
                clientSocket.Close();
                clientSocket = null;
                OnDisableSendMessage();
                StopCoroutine(Arranger());
                Destroy(this.gameObject);
            }
            else
            {
                Array.Resize<byte>(ref temp, bytesRec);
                Buffer.BlockCopy(buffer, 0, temp, 0, bytesRec);
                receivedBox.AddLast(temp);
                Array.Clear(buffer, 0, buffer.Length);
                Array.Clear(temp, 0, temp.Length);
            }

            yield return new WaitForSecondsRealtime(1f);
        }
    }

    IEnumerator Arranger()
    {
        bool isHeaderExtract = false;

        int data_len = 0;
        int remain_len = 0;
        int remain = 0;

        int count = 0;

        int body_len = 0;

        byte[] nodeData = null;
        byte[] addDate = null;
        byte[] header = {0,0,0,0};
        byte[] body = {0};

        while (true)
        {
            if (receivedBox.Count > 0)
            {
                nodeData = receivedBox.First.Value;
                receivedBox.RemoveFirst();
                if(!isHeaderExtract)
                {
                    body_len = (nodeData.Length - 4);
                    Array.Resize<byte>(ref body, body_len);
                    if (nodeData.Length < 4)
                    {
                        addDate = receivedBox.First.Value;
                        receivedBox.RemoveFirst();
                        Array.Resize<byte>(ref nodeData, (addDate.Length + nodeData.Length));
                        Buffer.BlockCopy(addDate, 0, nodeData, nodeData.Length, addDate.Length);
                        receivedBox.AddFirst(nodeData);
                        continue;
                    }
                    else
                    {
                        Buffer.BlockCopy(nodeData, 0, header, 0, header.Length);
                        data_len = BitConverter.ToInt32(header, 0);
                        remain_len = data_len;
                        Buffer.BlockCopy(nodeData, 4, body, 0, (nodeData.Length - 4));
                        receivedBox.AddFirst(body);
                        Array.Clear(header, 0, header.Length);
                        Array.Clear(body, 0, body.Length);
                    }
                    isHeaderExtract = true;
                }
                else
                {
                    remain_len -= nodeData.Length;
                    if(remain_len > 0)
                    {
                        arrangedBox.Enqueue(nodeData);
                    }
                    else if(remain_len < 0)
                    {
                        remain = remain_len + nodeData.Length;
                        Array.Resize<byte>(ref body, remain);
                        Buffer.BlockCopy(nodeData, 0, body, 0, body.Length);
                        arrangedBox.Enqueue(body);
                        Array.Clear(body, 0, body.Length);
                        Array.Resize<byte>(ref body, Math.Abs(remain_len));
                        Buffer.BlockCopy(nodeData, 0, body, 0, body.Length);
                        receivedBox.AddFirst(body);
                        Array.Clear(body, 0, body.Length);
                        count = arrangedBox.Count;
                        yield return StartCoroutine(VideoMaker(count, data_len));
                        isHeaderExtract = false;
                    }
                    else
                    {
                        arrangedBox.Enqueue(nodeData);
                        count = arrangedBox.Count;
                        yield return StartCoroutine(VideoMaker(count, data_len));
                        isHeaderExtract = false;
                    }
                }
            }
            yield return null;
        }
    }
    
    IEnumerator VideoMaker(int count, int data_len)
    {
        byte[] frame = new byte[data_len];
        byte[] temp = null;
        int startPoint = 0;

        for(int i=0; i< count; i++)
        {
            temp = arrangedBox.Dequeue();
            Buffer.BlockCopy(temp, 0, frame, startPoint, temp.Length);
            startPoint += temp.Length;
        }
        Texture2D tex = new Texture2D(640, 360);
        tex.LoadImage(frame);
        GetComponent<Renderer>().material.mainTexture = tex;
        tex.Apply();
        yield break;
    }

    /*
     * Put the SendMessageToClient method in sendMessageEvent event.
    */
    private void OnEnableSendMessage()
    {
        ServerManager.sendMessageEvent += SendMessageToClient;
    }

    /*
     * Put the SendMessageToClient method out sendMessageEvent event.
    */
    private void OnDisableSendMessage()
    {
        ServerManager.sendMessageEvent -= SendMessageToClient;
    }

    /*
     * This method send a message from server to client.
    */
    private void SendMessageToClient(string message)
    {
        Debug.Log(clientName + ": " + message);
        byte[] b_message = Encoding.UTF8.GetBytes(message);

        int msg_len = b_message.Length;
        byte[] b_msg_len = new byte[2];
        b_msg_len[0] = (byte)(msg_len);
        b_msg_len[1] = (byte)(msg_len >> 8);
        
        byte[] res_msg = new byte[b_message.Length + 2];
        Buffer.BlockCopy(b_msg_len, 0, res_msg, 0, 2);
        Buffer.BlockCopy(b_message, 0, res_msg, 2, b_message.Length);

        clientSocket.Send(res_msg);
        res_msg.Initialize();
    }
}
